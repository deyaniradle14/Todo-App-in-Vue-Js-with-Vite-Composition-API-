import { useCssModule } from "@vue/runtime-dom";

useCssModule.export = {
    purge: ['./index.html', './src/**/*.{vue,js,ts,jsx}'], darkMode:
        false, // or 'media' or 'class'
    theme: {
        extended: {},
    },
    variants: {
        extended: {},
    },
    plugins: [],
}