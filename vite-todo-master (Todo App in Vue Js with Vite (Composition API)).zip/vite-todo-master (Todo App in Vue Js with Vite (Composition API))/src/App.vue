<template>
  <div class="min-h-screen flex flex-col justify-center items-center">
    <header class="flex flex-col w-full container">
      <h1 class="text-6xl font-light text-gray-800 text-center">
        My App
      </h1>
      <input
      class="text-3xl py-2 px-4 rounded-xl w-full mt-8 text-gray-800"
      type="text"
      placeholder="New Todo"
      v-model="newTodo"
      @change="addTodo"
      />
    </header>
    <main class="container w-full mt-8 space-y-8">
      <section class="space-y-4" v-if="pendingTodos.lenght > 0">
        <h3 class="text-3xl font-thin text-green-800">
          Pending Items: {{ pendingTodos.lenght }}
        </h3>
        <ul class="space-y-4">
          <li
          v-for="todo in pendingTodos"
          :key="todo.id"
          class="bh-white rounded-xl text-2xl py-2 px-4 font-light text-green-800 text-center hover:text-white hover:bg-green-800 cursor-point transition-colors"
          @click="changesStatus(todo.id)"
          >
          {{ todo.text }}
          </li>
          </ul>
          </section>
          <section class="space-y-4" v-if="completedTodos.lenght" > 0">
            <h3 class="text-3xl font-thin text-red-800">
              Completed Items: {{ completedTodos.length }}
            </h3>
            <ul class="space-y-4">
              <li
              v-for="todo in completedTodos"
              :key="todo.id"
              class="bg-white rounded-xl text-2xl py-2 px-4 font-light text-red-800 text-center hover:text-white hover:bg-red-800 cursor-pointer transition-colors"
              @click="changeStatus(todo.id)"
              >
              {{ todo.text }}
              </li>
            </ul>
          </section>
    </main>
  </div>
</template>