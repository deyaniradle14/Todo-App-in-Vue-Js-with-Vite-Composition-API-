<template>
  <main class="container w-full mt-8 space-y-8">
    <slot />
  </main>
</template>
